from words_list_loader import WordsList
from aiogram import Bot, Dispatcher
from aiogram.filters.command import Command
from aiogram.types import Message
import asyncio


words_list = WordsList('wordslist.txt')
bot = Bot('6688982369:AAECb_prUNcXeDXLC7CuecmFydfi5W1oSXw')
dp = Dispatcher()
used_words = set()
last_word = ''

@dp.message(Command('start'))
async def start_command(message: Message):
    await message.answer('Бот для игры в слова на английском языке. Напишите ваше слово')

@dp.message()
async def receive_word(message: Message):
    global last_word
    last_char = message.text[-1].upper()
    if last_word != '': 
        if last_word[-1].upper() != message.text[0].upper():
            await message.answer('Вы ввели слово не на ту букву. Попробуйте заново')
            return
        if message.text.upper() in used_words:
            await message.answer('Вы уже вводили такое слово, попробуйте другое')
            return
    for word in words_list.get_list():
        if word[:3].upper() == 'TO ':
            word1 = ' '.join(word.split(' ')[1:]).upper()
        else:
            word1 = word.upper()
        if word1[0] == last_char and not word.upper() in used_words:
            used_words.add(word.upper())
            used_words.add(message.text.upper())
            await message.answer(word)
            last_word = word1
            return
    await message.answer('Я не могу подобрать слово на эту букву. Я проиграл. Напишите новое слово, если желаете возобновитьь игру.')

if __name__ == '__main__':
    asyncio.run(dp.start_polling(bot))