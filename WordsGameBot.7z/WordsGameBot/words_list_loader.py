class WordsList:

    def __init__(self, filename: str):
        self._words_list = []
        with open(filename, 'rt') as f:
            for line in f:
                sentence = line.replace('\n', '')
                sent = self._split_sentenses(sentence)
                if isinstance(sent, str):
                    self._words_list.append(sent)
                else:
                    for s in sent:
                        self._words_list.append(s)


    def _split_sentenses(self, s: str):
        if s.count('/') == 0:
            return s
        if s.count('/') == 1:
            sentenses = [s.strip() for s in s.split('/')]
            fswords = sentenses[0].split(' ')
            sswords = sentenses[1].split(' ')
            fsent = fswords.copy()
            ssent = fswords.copy()
            fsent.extend(sswords[1:])
            ssent = ssent[:-1]
            ssent.extend(sswords)
            return [' '.join(fsent), ' '.join(ssent)]
        if s.count('/') > 1:
            sentenses = [s.strip() for s in s.split('/')]
            ret = [sentenses[0]]
            for i in range(1, len(sentenses)):
                ret.append(f'{" ".join(sentenses[0].split(" ")[:-1])} {sentenses[i]}')
            return ret

    def get_list(self):
        return self._words_list